sudo /var/www/cam;
convert -resize "500x300" /var/www/image_bmp.bmp /var/www/time/$(date -d "today" +"%Y%m%d_%H%M%S").jpg
