<? 
phpinfo(); 
?> 