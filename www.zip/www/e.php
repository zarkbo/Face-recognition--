<?
echo 'he';
$file = 'light.txt';
$content = file_get_contents($file);
echo $content;
?>
