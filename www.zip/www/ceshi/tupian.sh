$1 > weixintupian.txt
