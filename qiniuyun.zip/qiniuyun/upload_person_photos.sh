#!/bin/sh
sudo /home/linaro/qiniuyun/camera

sudo convert -resize 1366x768  /home/linaro/qiniuyun/pictures/image_bmp.bmp /home/linaro/qiniuyun/php-sdk-6.1.11/docs/gist/person.jpg

cd /home/linaro/qiniuyun/php-sdk-6.1.11/docs/gist

php qiniu_upload.php

