#!/bin/sh
cd /home/linaro/qiniuyun/php-sdk-6.1.11/docs/gist
php qiniu_delete.php