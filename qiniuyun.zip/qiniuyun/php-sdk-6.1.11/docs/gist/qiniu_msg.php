<?php
#NJUPT_ming_QQ478959566
chdir('../..');
require_once('php/rs.php');
require_once('php/fop.php');
$person_name = 'NJUPT';
$key = $person_name.'.jpg';
$domain = 'obzmcslip.bkt.clouddn.com';
$accessKey = 'JvC1pSIELjxmQoMKGLPMrkZ-IMbME5WY6p7rS1FS';
$secretKey = '5cUtiaVWjOiAwPyuzFgaHpXVkjLwvZDTlgVgR5F5';
Qiniu_SetKeys($accessKey, $secretKey);
$baseUrl = Qiniu_RS_MakeBaseUrl($domain, $key);
$imgInfo = new Qiniu_ImageInfo;
$imgInfoUrl = $imgInfo->MakeRequest($baseUrl);
$getPolicy = new Qiniu_RS_GetPolicy();
$imgInfoPrivateUrl = $getPolicy->MakeRequest($imgInfoUrl, null);
echo "\nMsg_Url: ".$imgInfoPrivateUrl . "\n\n";
?>
