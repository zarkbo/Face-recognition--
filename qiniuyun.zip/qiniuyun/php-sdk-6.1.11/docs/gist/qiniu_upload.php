<?php
#NJUPT_ming_QQ478959566
chdir('../..');
require_once('php/rs.php');
require_once('php/io.php');
$bucket = 'facescanner';
$key = date('YmdHi').'.jpg';
$url1="http://obzmcslip.bkt.clouddn.com/".$key ;
$file1 = '/var/www/url_id.txt';
$fp = fopen($file1,'w');
echo fwrite($fp,$url1);
fclose($fp);

$file = 'docs/gist/person.jpg';
$accessKey = 'JvC1pSIELjxmQoMKGLPMrkZ-IMbME5WY6p7rS1FS';
$secretKey = '5cUtiaVWjOiAwPyuzFgaHpXVkjLwvZDTlgVgR5F5';
Qiniu_setKeys($accessKey, $secretKey);
$client = new Qiniu_MacHttpClient(null);
$err = Qiniu_RS_Delete($client, $bucket, $key);
$putPolicy = new Qiniu_RS_PutPolicy('facescanner');
$upToken = $putPolicy->Token(null);
$putExtra = new Qiniu_PutExtra();
$putExtra->Crc32 = 1;
list($ret, $err) = Qiniu_PutFile($upToken, $key, $file, $putExtra);
echo "\nQiniu_Upload result: \n";
if ($err !== null) 
{
	echo "********************************* \n";
    echo "The person failed to be uploaded! \n";
    echo "********************************* \n";
} 
else 
{
	echo "************************************ \n";
    echo "The person successed to be uploaded! \n";
    echo "************************************ \n\n";
}
?>