<?php
#NJUPT_ming_QQ478959566
chdir('../..');
require_once("php/rs.php");
require_once("php/fop.php");
$key = date('YmdHi').'.jpg';
$domain = 'obzmcslip.bkt.clouddn.com';
$accessKey = 'JvC1pSIELjxmQoMKGLPMrkZ-IMbME5WY6p7rS1FS';
$secretKey = '5cUtiaVWjOiAwPyuzFgaHpXVkjLwvZDTlgVgR5F5';
Qiniu_SetKeys($accessKey, $secretKey);  
$baseUrl = Qiniu_RS_MakeBaseUrl($domain, $key);
$imgView = new Qiniu_ImageView;
$imgView->Mode = 1;
$imgView->Width = 640;
$imgView->Height = 480;
$imgViewUrl = $imgView->MakeRequest($baseUrl);
$getPolicy = new Qiniu_RS_GetPolicy();
$imgViewPrivateUrl = $getPolicy->MakeRequest($imgViewUrl, null);
echo "\nView_Url: ".$imgViewPrivateUrl . "\n\n";
$file1 = '/var/www/url_id.txt';
$fp = fopen($file1,'w');
echo fwrite($fp,$imgViewPrivateUrl);
fclose($fp);
?>
