<?php
#NJUPT_ming_QQ478959566
chdir('../..');
require_once('php/rs.php');
$bucket = 'facescanner';
$person_name = 'NJUPT';
$key = $person_name.'.jpg';
$accessKey = 'JvC1pSIELjxmQoMKGLPMrkZ-IMbME5WY6p7rS1FS';
$secretKey = '5cUtiaVWjOiAwPyuzFgaHpXVkjLwvZDTlgVgR5F5';
Qiniu_SetKeys($accessKey, $secretKey);
$client = new Qiniu_MacHttpClient(null);
list($ret, $err) = Qiniu_RS_Stat($client, $bucket, $key);
echo "\nQiniu_Status result: \n";
if ($err !== null) 
{
	echo "*************************** \n";
    echo "The person was not existed! \n";
    echo "*************************** \n\n";
} 
else
{
	echo "*********************** \n";
    echo "The person was existed! \n";
    echo "*********************** \n\n";
}
?>